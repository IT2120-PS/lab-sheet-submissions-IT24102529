
# Faculty of Computing - Year 2 Semester 1 (2025)
# Course: IT2120 - Probability and Statistics
# Lab Sheet 02
# Student: Farhan FML (IT24102529)
# Date: 2025-09-25


# Q1. Without using R, determine the result of the computation
# x <- c(1, 2, 3)
# x[1] / x[2]^3 - 1 + 2 * x[3] - x[2 - 1]
# Manual calculation = 4.125

x <- c(1, 2, 3)
result_Q1 <- x[1] / x[2]^3 - 1 + 2 * x[3] - x[2 - 1]
print(result_Q1) 

# Q2. Vector 1:15 - count elements divisible by 3
v <- 1:15
count_div3 <- sum(v %% 3 == 0)
print(count_div3)  

# Q3. Loop to find index of maximum value
v <- c(10, 25, 7, 40, 18)
max_index <- 1
for (i in 2:length(v)) {
  if (v[i] > v[max_index]) {
    max_index <- i
  }
}
print(max_index) 

# Q4. Do Q3 without using a loop
max_index2 <- which.max(v)
print(max_index2) 